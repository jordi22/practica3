<?php

/**
 * Twenty Seventeen functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 */

/**
 * Twenty Seventeen only works in WordPress 4.7 or later.
 */
if (version_compare($GLOBALS['wp_version'], '4.7-alpha', '<')) {
	require get_template_directory() . '/inc/back-compat.php';
	return;
}

function load_my_widget()
{
	register_widget('my_widget1');
}
add_action('widgets_init', 'load_my_widget');

// Creamos el widget 
class my_widget1 extends WP_Widget
{

	public function __construct()
	{
		$widget_ops = array(
			'classname' => 'my_widget',
			'description' => 'My Widget is awesome',
		);
		parent::__construct('my_widget1', 'My Widget1', $widget_ops);
	}	


// Creamos la parte pública del widget

	public function widget($args, $instance)
	{
		$title = apply_filters('widget_title', "Nombre de la tienda");
		$NombreTienda = apply_filters('widget_text', $instance['NombreTienda']);
		$title2 = apply_filters('widget_title', "Direcci�n de la tienda");
		$DireccionTienda = apply_filters('widget_text', $instance['DireccionTienda']);


// los argumentos del antes y despues del widget vienen definidos por el tema
		echo $args['before_widget'];
		if (!empty($NombreTienda))
			echo $args['before_title'] . $title . $args['after_title'];
		echo $NombreTienda;
		if (!empty($DireccionTienda))
			echo $args['before_title'] . $title2 . $args['after_title'];
		echo $DireccionTienda;
// Aquí es donde debemos introducir el código que queremos que se ejecute
		echo $args['after_widget'];
	}
		
// Backend  del widget
	public function form($instance)
	{
		if (isset($instance['NombreTienda'])) {
			$NombreTienda = $instance['NombreTienda'];
			$DireccionTienda = $instance['DireccionTienda'];
		} else {
			$title = __('NombreTienda', 'my_widget_domain');
		}
// Formulario del backend
		?>
<p>
<label for="<?php echo $this->get_field_id('NombreTienda'); ?>"><?php _e('Nombre de la Tienda:'); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id('NombreTienda'); ?>" name="<?php echo $this->get_field_name('NombreTienda'); ?>" type="text" value="<?php echo esc_attr($NombreTienda); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id('DireccionTienda'); ?>"><?php _e('Direccion de la Tienda:'); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id('DireccionTienda'); ?>" name="<?php echo $this->get_field_name('DireccionTienda'); ?>" type="text" value="<?php echo esc_attr($DireccionTienda); ?>" />
</p>
<?php	
}
// Actualizamos el widget reemplazando las viejas instancias con las nuevas
public function update($new_instance, $old_instance)
{
	$instance = array();
	$instance['NombreTienda'] = (!empty($new_instance['NombreTienda'])) ? strip_tags($new_instance['NombreTienda']) : '';
	$instance['DireccionTienda'] = (!empty($new_instance['DireccionTienda'])) ? strip_tags($new_instance['DireccionTienda']) : '';

	return $instance;
}
} // La clase wp_widget termina aqui



//WIDGET DE GALERIA.//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function load_my_widget2()
{
	register_widget('my_galeria');
}
add_action('widgets_init', 'load_my_widget2');

// Creamos el widget 
class my_galeria extends WP_Widget
{

	public function __construct()
	{
		$widget_ops = array(
			'classname' => 'my_widget',
			'description' => 'My Widget for galeries.',
		);
		parent::__construct('my_galeria', 'My Galeria', $widget_ops);
	}	


// Creamos la parte pública del widget

	public function widget($args, $instance)
	{



// los argumentos del antes y despues del widget vienen definidos por el tema
		echo $args['before_widget'];


		$current_user = wp_get_current_user();
		$user_email = $current_user->user_email;

		if (current_user_can('manage_options')) {
			echo "Hola Admin";
		} else {
			echo "Hola Usuario";
		}


		$table = 'A_GrupoCliente';
		$MP_pdoSportRunner = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASSWORD);

		$a = array();
		$foto = 'foto_file';
		$campo = 'clienteMail';
		$query = "SELECT     $foto FROM  $table      WHERE $campo =?";
		$a = array($user_email);
		$consult = $MP_pdoSportRunner->prepare($query);
		$a = $consult->execute($a);
		$rows = $consult->fetchAll(PDO::FETCH_ASSOC);

		if (is_array($rows)) {/* Creamos un listado como una tabla HTML*/
			print '<div><table>';
			foreach ($rows as $row) {
				print "<tr>";
				foreach ($row as $key => $val) {
					if ($key == "foto_file") {
						echo "<td>", "<img src='$val' width=100 height=100>", "</td>";
					} else {
						echo "<td>", $val, "</td>";
					}
				}
				print "</tr>";
			}
			print "</table></div>";

		}

// Aquí es donde debemos introducir el código que queremos que se ejecute
		echo $args['after_widget'];

	}

// Backend  del widget
	public function form($instance)
	{

// Formulario del backend
	}
// Actualizamos el widget reemplazando las viejas instancias con las nuevas

} // La clase wp_widget termina aqui
?>
