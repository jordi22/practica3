 <?php
$path = getcwd();
echo "La ruta absoluta es: ";
echo $path;
?>